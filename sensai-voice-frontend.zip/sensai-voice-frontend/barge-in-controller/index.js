// Barge-in Controller

export class BargeInController {
  constructor(voiceInput, voiceOutput) {
    this.voiceInput = voiceInput;
    this.voiceOutput = voiceOutput;
    this.isListeningForBargeIn = false;
    this.bargeInKeywords = ['stop', 'pause', 'wait', 'hold on', 'interrupt'];
    this.onBargeInCallback = null;
    this.recognition = null;
    this.setupRecognition();
  }

  setupRecognition() {
    if ('webkitSpeechRecognition' in window) {
      this.recognition = new webkitSpeechRecognition();
    } else if ('SpeechRecognition' in window) {
      this.recognition = new SpeechRecognition();
    } else {
      console.warn('Speech recognition not available for barge-in');
      return;
    }

    this.recognition.continuous = true;
    this.recognition.interimResults = true;
    this.recognition.lang = 'en-US';

    this.recognition.onresult = (event) => {
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript.toLowerCase();
        
        // Check for barge-in keywords
        if (event.results[i].isFinal) {
          const detectedKeyword = this.detectBargeInKeyword(transcript);
          if (detectedKeyword) {
            this.handleBargeIn(detectedKeyword);
          }
        }
      }
    };

    this.recognition.onerror = (event) => {
      console.error('Barge-in recognition error:', event.error);
    };
  }

  detectBargeInKeyword(transcript) {
    for (const keyword of this.bargeInKeywords) {
      if (transcript.includes(keyword)) {
        return keyword;
      }
    }
    return null;
  }

  handleBargeIn(keyword) {
    console.log(`Barge-in detected: "${keyword}"`);
    
    // Stop the voice output
    if (this.voiceOutput && this.voiceOutput.isCurrentlySpeaking()) {
      this.voiceOutput.stop();
    }
    
    // Stop listening for barge-in
    this.stopListeningForBargeIn();
    
    // Call the callback
    if (this.onBargeInCallback) {
      this.onBargeInCallback(keyword);
    }
  }

  startListeningForBargeIn() {
    if (this.recognition && !this.isListeningForBargeIn) {
      this.recognition.start();
      this.isListeningForBargeIn = true;
      console.log('Barge-in listening started');
    }
  }

  stopListeningForBargeIn() {
    if (this.recognition && this.isListeningForBargeIn) {
      this.recognition.stop();
      this.isListeningForBargeIn = false;
      console.log('Barge-in listening stopped');
    }
  }

  setBargeInKeywords(keywords) {
    this.bargeInKeywords = keywords;
  }

  onBargeIn(callback) {
    this.onBargeInCallback = callback;
  }

  // Auto-start barge-in listening when voice output starts
  setupAutoBargeIn() {
    if (this.voiceOutput) {
      this.voiceOutput.onStart(() => {
        this.startListeningForBargeIn();
      });
      
      this.voiceOutput.onEnd(() => {
        this.stopListeningForBargeIn();
      });
    }
  }
}
