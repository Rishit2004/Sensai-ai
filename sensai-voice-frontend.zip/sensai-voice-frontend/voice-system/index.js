// Complete Voice System Integration

import { WebSpeechRecognition } from '../voice-input/index.js';
import { VoiceOutput } from '../voice-output/index.js';
import { UIHighlightController } from '../ui-highlight-controller/index.js';
import { BargeInController } from '../barge-in-controller/index.js';
import { UserConfirmationHandler } from '../user-confirmation-handler/index.js';

export class VoiceSystem {
  constructor() {
    // Initialize all modules
    this.voiceInput = new WebSpeechRecognition();
    this.voiceOutput = new VoiceOutput();
    this.uiHighlight = new UIHighlightController();
    this.bargeIn = new BargeInController(this.voiceInput, this.voiceOutput);
    this.confirmation = new UserConfirmationHandler(this.voiceInput);
    
    // Setup auto barge-in
    this.bargeIn.setupAutoBargeIn();
    
    // State management
    this.isActive = false;
    this.currentStep = null;
  }

  // Start the voice system
  start() {
    this.isActive = true;
    console.log('Voice system started');
  }

  // Stop the voice system
  stop() {
    this.isActive = false;
    this.voiceOutput.stop();
    this.bargeIn.stopListeningForBargeIn();
    this.confirmation.stopWaitingForConfirmation();
    console.log('Voice system stopped');
  }

  // Speak text and highlight UI elements
  speakAndHighlight(text, selector = null, highlightType = 'default') {
    if (selector) {
      this.uiHighlight.highlight(selector, highlightType);
    }
    
    this.voiceOutput.speak(text);
  }

  // Listen for user input
  listenForInput(callback) {
    this.voiceInput.onResult((text, isFinal) => {
      if (isFinal && this.isActive) {
        callback(text);
      }
    });
    
    this.voiceInput.startListening();
  }

  // Ask for confirmation
  askForConfirmation(question, callback) {
    this.confirmation.askForConfirmation(question, callback);
  }

  // Set up barge-in callback
  onBargeIn(callback) {
    this.bargeIn.onBargeIn(callback);
  }

  // Click an element
  clickElement(selector) {
    this.uiHighlight.clickElement(selector);
  }

  // Focus an element
  focusElement(selector) {
    this.uiHighlight.focusElement(selector);
  }

  // Clear all highlights
  clearHighlights() {
    this.uiHighlight.unhighlightAll();
  }

  // Set barge-in keywords
  setBargeInKeywords(keywords) {
    this.bargeIn.setBargeInKeywords(keywords);
  }

  // Set confirmation keywords
  setConfirmationKeywords(keywords) {
    this.confirmation.setConfirmationKeywords(keywords);
  }

  // Get available voices
  getAvailableVoices() {
    return this.voiceOutput.getVoices();
  }

  // Set voice for output
  setVoice(voice) {
    this.voiceOutput.speak('', { voice: voice });
  }
}
