# Sensai Voice Backend

FastAPI backend for handling voice transcription using OpenAI Whisper API.

## Setup

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Set up environment variables:**
   Create a `.env` file in this directory with:
   ```
   OPENAI_API_KEY=your_openai_api_key_here
   ```

3. **Run the server:**
   ```bash
   python main.py
   ```
   
   The server will start on `http://localhost:8002`

## Endpoints

- `POST /transcribe` - Upload audio file for transcription
- `GET /health` - Health check endpoint

## Integration

The frontend will automatically connect to this backend when you open the demo HTML file.
